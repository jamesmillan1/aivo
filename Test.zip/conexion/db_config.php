<?php

	define('DB_USER', "tachinav_jmillan");
	define('DB_PASSWORD', "jmillan");
	define('DB_DATABASE', "tachinav_twitter");
	define('DB_SERVER', "localhost");
	
?>