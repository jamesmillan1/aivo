Test Back end // Aivo

JAMES MILLAN
13/10/2018

Prueba Realizada con PHP, Boostrap, Jquery, Ajax y Base de datos MySql.

1.  Copiar los archivos del fichero Test.zip en la carpeta www
2.  Abrir el archivo twitter.sql el cual contiene los scripts para la creacion de la Base de Datos y las tablas.
3.  Copiar los scripts y ejecutarlos en phpmyAdmin.
3.  Ubicarse en la carpeta conexion y abrir el archivo db_config.sql reemplazar los valores del usuario y password (define('DB_USER', "xxxxxx");  define('DB_PASSWORD', "xxxxxx");)
4.  Para validar el archivo que retorna el arreglo, ingresar desde el navegador a la ruta http://localhost/Test/endpoint.php
5.  Para ver el programa en funcionamiento ingresar a http://localhost/Test/index.php